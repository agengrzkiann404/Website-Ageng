<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('wisatas.update', $wisata->id)); ?>" method="post" enctype="multipart/form-data" class="form">
<?php echo csrf_field(); ?> 
<?php echo method_field('PUT'); ?>

<label for="">Nama</label><br>
<input type="text" name="nama" id="" value="<?php echo e($wisata->nama); ?>"><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" value="<?php echo e($wisata->kota); ?>"<br>

<label for="">Harga Tiket</label><br>
<input type="decimal" name="harga_tiket" id="" value="<?php echo e($wisata->harga_tiket); ?>"><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Update" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata2/resources/views/wisatas/edit.blade.php ENDPATH**/ ?>