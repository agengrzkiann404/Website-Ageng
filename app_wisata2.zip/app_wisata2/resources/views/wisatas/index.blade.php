@extends('wisatas.layout')

@section('content')

<a href="{{ route('wisatas.create') }}" class="btn btn-primary">Add New</a>

<table class="table">
<tr>
<th>ID</th>
<th>Nama</th>
<th>Kota</th>
<th>Harga Tiket</th>
<th>Action</th>
</tr>

@foreach ($wisatas as $wisata)
<tr>
<td>{{ $wisata->id }}</td>
<td><img src="{{ Storage::url('public/images/' . $wisata->image) }}" alt="" style="width: 150px;"></td>
<td>{{ $wisata->nama }}</td>
<td>{{ $wisata->kota }}</td>
<td>{{ $wisata->harga_tiket }}</td>
<td>
<a href="{{ route('wisatas.show', $wisata->id) }}" class="btn btn-success">Show</a>
<a href="{{ route('wisatas.edit', $wisata->id) }}" class="btn btn-warning">Edit</a>
<form onclick="return confirm('Are you sure?')" action="{{ route('wisatas.destroy', $wisata->id) }}" method="post">
@csrf 
@method('DELETE')
<button class="btn btn-danger">Delete</button>
</form>
</td>
</tr>
@endforeach

</table>

{{ $wisatas->links() }}

@endsection